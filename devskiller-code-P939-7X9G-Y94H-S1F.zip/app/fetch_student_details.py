import csv

from app.student import Student


class FetchStudentDetails:
    student_list = None
    headers = None

    def __init__(self):
        self.headers = []
        self.student_list = []

    @staticmethod
    def clean_input(row):
        """
        Clean and sanitize the input so that it does not contain leading and trailing spaces
        """
        return [r.strip() for r in row]

    @staticmethod
    def map_csv_to_class(row):
        """
        Convert the input row into a Student class
        """
        return Student(*row)

    def get_data(self, file_name="./app/data/student_details.csv"):
        """
        Fetch the data from the given csv file and construct the list of Student objects
        """
        with open(file_name, newline="") as _file:
            reader = csv.reader(
                _file,
                delimiter=",",
                quotechar='"',
                quoting=csv.QUOTE_ALL,
                skipinitialspace=True,
            )
            # set here self.headers (first row)
            # set here self.student_list consider using clean_input() and map_csv_to_class()
        return self.student_list

    def get_super_student(self):
        """
        Get super student
        """

    def get_attendance(self, attendance_file_name="./app/data/attendance.csv"):
        """
        Fetch data from given csv file and update students attendance
        """
